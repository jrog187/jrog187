const timeLine = gsap.timeline({defaults: {duration: 0.75}})

timeLine.fromTo('.prenav',{opacity:0, y:-50},{opacity: 1, y:0})
timeLine.fromTo('.navbar',{opacity:0, y:-50},{opacity: 1, y:0},'<')

timeLine.fromTo('.message',{opacity:0},{opacity:1, duration: 2},'<')
timeLine.fromTo('.calendar',{opacity:0},{opacity:1, duration: 2},'<')
timeLine.fromTo('.person',{opacity:0},{opacity:1, duration: 2},'<')



timeLine.fromTo('.first-container', {opacity: 0, y: 50}, {opacity: 1, y: 0},'<')
timeLine.fromTo('.service-container', {opacity: 0, y: 50}, {opacity: 1, y: 0},'<')
timeLine.fromTo('.contact-container', {opacity: 0, y: 50}, {opacity: 1, y: 0},'<')


timeLine.fromTo('.intro', {opacity: 0, y: 50}, {opacity: 1, y: 0},'<')
timeLine.fromTo('.pillars', {opacity: 0, y: 50}, {opacity: 1, y: 0},'<40%')
